// nuxt.config.ts
import { defineNuxtConfig } from 'nuxt/config'
import tailwindcss from '@tailwindcss/vite'

export default defineNuxtConfig({
  // Базовые настройки
  devServer: {
    port: 3001
  },
  
  srcDir: 'app',

  future: {
    compatibilityVersion: 4,
  },

  app: {
    baseURL: '/',
    head: {
      charset: 'utf-8',
      viewport: 'width=device-width, initial-scale=1, maximum-scale=1',
      title: 'Журнал КПП',
      meta: [
        { name: 'description', content: 'Система контроля пропускного пункта' },
        { name: 'theme-color', content: '#1d232a' },
        { name: 'apple-mobile-web-app-capable', content: 'yes' },
        { name: 'apple-mobile-web-app-status-bar-style', content: 'black-translucent' },
        { name: 'robots', content: 'noindex, nofollow' },
      ],
      link: [
        // ⚠️ Убедитесь, что файл существует: public/favicon.svg
        { rel: 'icon', type: 'image/svg+xml', href: '/favicon.svg' },
        { rel: 'apple-touch-icon', href: '/pwa-192x192.png' },
      ],
    },
  },

  css: ['~/assets/css/main.css'],

  modules: [
    '@vite-pwa/nuxt'
  ],

  vite: {
    optimizeDeps: {
      include: [
        '@vue/devtools-core',
        '@vue/devtools-kit',
        'fuse.js',
        'gsap',
      ],
    },
    plugins: [tailwindcss()],
  },

  pwa: {
    registerType: 'autoUpdate',
    manifest: {
      name: 'Журнал КПП',
      short_name: 'КПП',
      description: 'Система контроля пропускного пункта',
      theme_color: '#1d232a',
      background_color: '#1d232a',
      display: 'standalone',
      orientation: 'portrait-primary',
      start_url: '/',
      icons: [
        { src: 'pwa-192x192.png', sizes: '192x192', type: 'image/png' },
        { src: 'pwa-512x512.png', sizes: '512x512', type: 'image/png' },
        { src: 'pwa-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
      ],
    },
    workbox: {
      navigateFallback: '/index.html',
      globPatterns: ['**/*.{js,css,html,ico,png,svg,woff2}'],
      navigateFallbackDenylist: [/^\/api/],
      runtimeCaching: [
        {
          urlPattern: /\.(png|jpg|jpeg|svg|gif|webp)$/,
          handler: 'CacheFirst',
          options: {
            cacheName: 'images',
            expiration: { maxEntries: 60, maxAgeSeconds: 30 * 24 * 60 * 60 },
          },
        },
      ],
    },
    devOptions: {
      enabled: false,
    },
  },

  nitro: {
    prerender: {
      htmlExtension: true,
      routes: ['/', '/editor', '/database', '/settings', '/reports'],
    },
    routeRules: {
      '/': { ssr: true }
    }
  },

  compatibilityDate: '2024-11-01',
})