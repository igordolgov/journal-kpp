<!-- app/components/editor/TrajectoryEditor.vue -->
<template lang='pug'>
.rounded.p-2.bg-gray-800
  template(v-for="section in sections" :key="section.title")
    .text-xxs.font-bold.mb-1(:class="section.color") {{ section.title }}
    .text-xxs.text-gray-500.mb-1.ml-3(v-if="section.subtitle") {{ section.subtitle }}
    template(v-for="point in section.points" :key="point.prefix")
      .text-xxs.text-gray-500.mb-1.ml-3(:class="point.color") {{ point.emoji }} {{ point.label }}
      .grid.grid-cols-2.gap-x-2.gap-y-1.mb-2.ml-3
        .flex.items-center.gap-1
          span.w-10.text-xxs(:class="point.color") {{ point.emoji }} X:
          input.input.input-xs.input-bordered.w-full.bg-gray-900(type="number" step="1"
            :value="settings?.[point.prefix+'X'] ?? ''"
            @input="update(point.prefix, 'x', $event)")
        .flex.items-center.gap-1
          span.w-10.text-xxs(:class="point.color") {{ point.emoji }} Y:
          input.input.input-xs.input-bordered.w-full.bg-gray-900(type="number" step="1"
            :value="settings?.[point.prefix+'Y'] ?? ''"
            @input="update(point.prefix, 'y', $event)")
</template>

<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
  settings: Record<string, any> | null
  gateType: string | null | undefined
}>()

const emit = defineEmits<{
  (e: 'update:settings', settings: Record<string, any>): void
}>()

interface TrajectoryPoint {
  prefix: string      // например, 'spawnEnterCar'
  label: string       // 'Спавн (появление снаружи)'
  emoji: string       // '🚗' или '👤'
  color: string       // класс цвета Tailwind
}

interface TrajectorySection {
  title: string
  subtitle?: string
  color: string
  points: TrajectoryPoint[]
}

const sections = computed<TrajectorySection[]>(() => {
  const gate = props.gateType
  if (!gate) return []

  const isCar = gate === 'sliding'
  const emoji = isCar ? '🚗' : '👤'
  const enterColor = isCar ? 'text-green-400' : 'text-green-400'
  const exitColor = isCar ? 'text-red-400' : 'text-red-400'

  const enterPrefix = isCar ? 'EnterCar' : 'EnterPerson'
  const exitPrefix = isCar ? 'ExitCar' : 'ExitPerson'

  const makeSection = (direction: 'enter' | 'exit', color: string, emoji: string, prefix: string) => {
    const points: TrajectoryPoint[] = [
      { prefix: `spawn${prefix}`, label: 'Спавн', emoji, color: 'text-green-400' },
      { prefix: `stop${prefix}`, label: 'Остановка', emoji, color: direction === 'enter' ? (isCar ? 'text-orange-400' : 'text-cyan-400') : (isCar ? 'text-pink-400' : 'text-purple-400') },
      { prefix: `cross${prefix}`, label: 'Движение', emoji, color: 'text-yellow-400' },
      { prefix: `despawn${prefix}`, label: 'Деспавн', emoji, color: 'text-gray-400' }
    ]
    const title = direction === 'enter' ? (isCar ? '⬇ ВЪЕЗД АВТО' : '⬇ ВХОД ПЕШЕХОДА') : (isCar ? '⬆ ВЫЕЗД АВТО' : '⬆ ВЫХОД ПЕШЕХОДА')
    return { title, color, points }
  }

  return [
    makeSection('enter', enterColor, emoji, enterPrefix),
    makeSection('exit', exitColor, emoji, exitPrefix)
  ]
})

const update = (prefix: string, axis: 'x' | 'y', event: Event) => {
  const rawValue = (event.target as HTMLInputElement).value
  const newSettings = { ...(props.settings || {}) }
  const key = `${prefix}${axis.toUpperCase()}`
  if (rawValue === '' || rawValue === null) {
    delete newSettings[key]
  } else {
    newSettings[key] = Number(rawValue)
  }
  emit('update:settings', newSettings)
}
</script>